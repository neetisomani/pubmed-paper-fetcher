import pytest
from unittest.mock import patch, Mock
from pubmed_paper_fetcher import fetcher

# Sample PubMed ESearch response
mock_esearch_response = {
    "esearchresult": {
        "idlist": ["123456", "789101"]
    }
}

# Sample PubMed EFetch XML response (minimal but valid)
mock_efetch_response = """
<PubmedArticleSet>
  <PubmedArticle>
    <MedlineCitation>
      <PMID>123456</PMID>
      <Article>
        <ArticleTitle>Sample Pharma Study</ArticleTitle>
        <AuthorList>
          <Author>
            <LastName>Smith</LastName>
            <ForeName>Jane</ForeName>
            <AffiliationInfo>
              <Affiliation>Pfizer Inc., R&D Center, USA. jane@pfizer.com</Affiliation>
            </AffiliationInfo>
          </Author>
        </AuthorList>
      </Article>
      <ArticleDate>
        <Year>2023</Year>
      </ArticleDate>
    </MedlineCitation>
  </PubmedArticle>
</PubmedArticleSet>
"""

@patch("pubmed_paper_fetcher.fetcher.requests.get")
def test_fetch_and_process_papers(mock_get):
    # Step 1: Mock ESearch JSON response
    mock_get.side_effect = [
        Mock(status_code=200, json=lambda: mock_esearch_response),
        Mock(status_code=200, content=mock_efetch_response.encode("utf-8"))
    ]

    result = fetcher.fetch_and_process_papers("pharma covid", debug=False)

    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]["PubmedID"] == "123456"
    assert "Smith" in result[0]["Non-academicAuthor(s)"]
    assert "Pfizer" in result[0]["CompanyAffiliation(s)"]
    assert result[0]["Corresponding Author Email"] == "jane@pfizer.com"
