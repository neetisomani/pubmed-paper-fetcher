import pytest
from pubmed_paper_fetcher.utils import is_non_academic_affiliation, extract_email

def test_is_non_academic_affiliation_positive():
    assert is_non_academic_affiliation("Pfizer Inc., R&D Center, USA") is True
    assert is_non_academic_affiliation("BioGen Biotech Pvt Ltd") is True

def test_is_non_academic_affiliation_negative():
    assert is_non_academic_affiliation("Department of Biology, Harvard University") is False
    assert is_non_academic_affiliation("School of Medicine, Oxford") is False

def test_extract_email_found():
    text = "Roche Ltd., Basel, Switzerland. Email: jane.doe@roche.com"
    assert extract_email(text) == "jane.doe@roche.com"

def test_extract_email_not_found():
    text = "Department of Chemistry, Cambridge University"
    assert extract_email(text) is None
