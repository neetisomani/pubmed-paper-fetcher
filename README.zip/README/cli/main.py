import argparse
from pubmed_paper_fetcher.fetcher import fetch_and_process_papers, save_results_to_csv

def main():
    parser = argparse.ArgumentParser(
        description="Search academic papers and extract metadata."
    )
    parser.add_argument(
        "-q", "--query", required=True, help="Search query for Europe PMC"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug output during fetching"
    )
    parser.add_argument(
        "--save", action="store_true", help="Save results to results.csv"
    )

    args = parser.parse_args()
    query = args.query
    debug = args.debug
    save = args.save

    print(f"🔍 Searching Europe PMC for: '{query}' (max 100)")
    papers = fetch_and_process_papers(query, debug=debug)

    if not papers:
        print("⚠️ No results with non-academic authors found.")
        return

    print(f"🔢 Found {len(papers)} articles")
    print(f"✅ Processed {len(papers)} results")

    for i, paper in enumerate(papers[:10], start=1):
        print(f"\n📄 Paper {i}:")
        print(f"🆔 PubMed ID: {paper.get('PubmedID', '-')}")
        print(f"📝 Title: {paper.get('Title', '-')}")
        print(f"📅 Published: {paper.get('Publication Date', '-')}")
        print(f"👥 Authors: {paper.get('Authors', '-')}")
        print(f"🏢 Affiliations: {paper.get('Affiliations', '-')}")
        print(f"📧 Emails: {paper.get('Emails', '-')}")

    if save:
        save_results_to_csv(papers)
        print("💾 Results saved to results.csv")

if __name__ == "__main__":
    main()
