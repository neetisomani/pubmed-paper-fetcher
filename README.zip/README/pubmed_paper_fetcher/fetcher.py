import requests
import xml.etree.ElementTree as ET
import time
import csv
from typing import List, Dict, Any
from pubmed_paper_fetcher.utils import is_non_academic_affiliation, extract_email

# Europe PMC API
ESEARCH_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"

# Retry config
MAX_RETRIES = 3
RETRY_BACKOFF = 2  # seconds

def fetch_with_retries(url: str, params: dict, debug: bool = False) -> dict:
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            if debug:
                print(f"⚠️ Attempt {attempt}: Error → {e}")
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_BACKOFF * attempt)
            else:
                raise

def fetch_and_process_papers(query: str, debug: bool = False, retmax: int = 100) -> List[Dict[str, Any]]:
    if debug:
        print(f"🔍 Searching Europe PMC for: '{query}' (max {retmax})")

    search_params = {
        "query": query,
        "format": "json",
        "pageSize": retmax
    }

    try:
        search_data = fetch_with_retries(ESEARCH_URL, search_params, debug=debug)
    except Exception as e:
        print(f"❌ Error fetching search results: {e}")
        return []

    articles = search_data.get("resultList", {}).get("result", [])

    if debug:
        print(f"🔢 Found {len(articles)} articles")

    results = []

    for entry in articles:
        try:
            pmid = entry.get("id", "Unknown")
            title = entry.get("title", "No Title")
            pub_date = entry.get("firstPublicationDate", "Unknown")
            author_string = entry.get("authorString", "")
            author_list = author_string.split(", ") if author_string else []

            # Use affiliationText if available
            affiliations = entry.get("affiliation", "")
            emails = extract_email(affiliations)
            all_authors_info = []

            for author in author_list:
                affil = affiliations  # EuropePMC has one common field
                is_non_academic = is_non_academic_affiliation(affil)
                author_type = "Non-Academic" if is_non_academic else "Academic"
                all_authors_info.append(f"{author} ({author_type})")

            results.append({
                "PubmedID": pmid,
                "Title": title,
                "Publication Date": pub_date,
                "Authors": "; ".join(all_authors_info),
                "Affiliations": affiliations,
                "Emails": "; ".join(emails) if emails else "Not found"
            })

        except Exception as e:
            if debug:
                print(f"⚠️ Skipping article due to error: {e}")
            continue

    if debug:
        print(f"✅ Processed {len(results)} results")

    return results

def save_results_to_csv(results: List[Dict[str, Any]], filename="results.csv"):
    if not results:
        print("⚠️ No results to save.")
        return
    keys = results[0].keys()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(results)
    print(f"📁 Results saved to {filename}")
