import re
from typing import Optional

# Keywords that often appear in academic affiliations
ACADEMIC_KEYWORDS = [
    "university", "college", "institute of technology", "school of",
    "department of", "faculty of", "hospital", "centre for", "academy",
    "medical center", "universität", "research institute"
]

# Keywords that hint at non-academic (corporate) affiliations
NON_ACADEMIC_KEYWORDS = [
    "inc", "ltd", "llc", "corporation", "pharmaceutical", "biotech", 
    "company", "group", "gmbh", "co.", "r&d", "research center"
]

EMAIL_REGEX = r"[\w\.-]+@[\w\.-]+\.\w+"

def is_non_academic_affiliation(affiliation: str) -> bool:
    """
    Returns True if the affiliation seems non-academic (e.g., company, pharma).
    """
    affil = affiliation.lower()

    if any(word in affil for word in NON_ACADEMIC_KEYWORDS):
        return True
    if any(word in affil for word in ACADEMIC_KEYWORDS):
        return False

    # Default to academic if unclear
    return False

def extract_email(text: str) -> Optional[str]:
    """
    Extract the first email address found in the text, if any.
    """
    match = re.search(EMAIL_REGEX, text)
    return match.group(0) if match else None

